﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OceanicAirlinesNET.Models.ApiModel
{
    public class PlaceOrderRequest
    {
        public int offerID { get; set; }
        /// <summary>
        /// Name of the company/application that is placing the offer
        /// </summary>
        public string cooperantName { get; set; }
    }
}